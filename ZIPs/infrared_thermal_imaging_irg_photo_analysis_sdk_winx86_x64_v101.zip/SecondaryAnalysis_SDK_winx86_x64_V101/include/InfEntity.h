#pragma once

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__)
#define JUST_WIN32
#elif defined(linux) || defined(__linux) || defined(__linux__)
#define JUST_LINUX
#endif

#ifdef JUST_LINUX
#include "LinuxDef.h"
#endif

#pragma pack (1) 
typedef struct
{
	int emissivity;
	int airTemp;
	int reflectTemp;
	int humidity;
	int distance;
	int atmTrans;
	int K0;
	int B0;
	int K1;
	int B1;
} JPG_envir_param; //Parameters are actual values * 10000

typedef struct
{
	int max;       //K*10
	int min;       //K*10
	int frameMax;  //K*10
	int frameMin;  //K*10
	int width;
	int height;
	int pseudoColorIndex;//Pseudo-color number
} Stretch_param;

typedef struct
{
	unsigned short width;  //width
	unsigned short height;   //height

	int emiss; // Emissivity*10000
	int airTemp; //Ambient temperature*10000   K
	unsigned int distance;  //distance *10000
	unsigned char humidity;  //Humidity*10000
	int refTemp;  //Reflected temperature*10000  K
	int atmTrans; //Atmospheric transmittance*10000

	int K0; //K0  *10000
	int B0; //B0  *10000
	int K1; //K1  *10000
	int B1; //B1  *10000
	int pseudoColorIndex;//Pseudo-color number
	int unit;  //temp unit
	int gainStatus;  //0:highGain     1:lowGain
}IRG_Param;

#pragma pack ()
